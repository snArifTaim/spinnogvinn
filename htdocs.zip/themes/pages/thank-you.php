<?php get_header(); ?>
<div class="page-template-default">
    <section class='page__content taimbro-sec'>
        <h1 style="padding-bottom: 1em">Takk for Innsending</h1>
        <div class='form-group'>
            <a class='main-button' href='#'>Tilbake til innlogging</a>
        </div>
    </section>
</div>
<?php get_footer(); ?>