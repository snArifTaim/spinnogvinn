<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="footer-block">
                <div class="decor">
                    <img class="ls-is-cached lazyloaded" src="<?php echo get_url('/assets/img/banana.png') ?>" />
                </div>
                <a href="<?php echo get_url('/')?>" class="footer-logo">
                    <img class=" ls-is-cached lazyloaded" src="<?php echo $_ENV['footer_logo']; ?>" >
                </a>
                <div class="footer-info">
                    <div class="disclaimer">
                        <p><strong>Ansvarsfriskrivning</strong><br /> Hos vårt casino betaler du aldri med ekte penger og vi vil aldri betale ut gevinster i form av ekte penger. Vi vil heller ikke arrangere lotterier eller konkurranser med pengepremier. Her handler
                            det om spilleglede, og ikke om stresset det kan innebære å satse egne penger på gambling. På vårt gratis casino har vi 18 års aldersgrense. Du må derfor være myndig for å ta del i underholdningen her på siden fordi spillene er
                            laget for voksne.</p>
                    </div>
                </div>
                <div class="footer-info-2"></div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="copyright">Copyright © <?php echo date('Y');?> - <?php echo $_ENV['app_name'];?></div>
    </div>
</footer>

</div>
</div>

</body>

<script src="<?php echo get_url('/assets/js/script.js')?>"></script>
</html>