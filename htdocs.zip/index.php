<?php 
define('app_dir',__DIR__);

include app_dir.'/vendor/autoload.php';

//run main file 
require_once app_dir.'/app/load.php';

